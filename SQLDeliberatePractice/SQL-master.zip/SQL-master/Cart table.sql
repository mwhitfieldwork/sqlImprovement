USE CityTour

go

CREATE TABLE Cart
  (
     Id         INT,
     CustomerId INT
  ) 
