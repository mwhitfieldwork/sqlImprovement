USE CityTour

go

CREATE TABLE Customer
  (
     Id        INT,
     NAME      VARCHAR(50),
     AddressId INT,
     Phone     INT,
     Email     VARCHAR(50)
  ) 
