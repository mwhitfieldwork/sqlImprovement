USE CityTour

go

CREATE TABLE ProductImage
  (
     Id        INT,
     Url       VARCHAR(100),
     ProductId INT
  ) 
