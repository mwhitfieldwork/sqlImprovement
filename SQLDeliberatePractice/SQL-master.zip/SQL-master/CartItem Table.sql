USE CityTour

go

CREATE TABLE CartItem
  (
     Id        INT,
     ProductId INT,
     Total     MONEY,
     Quantity  INT
  ) 
