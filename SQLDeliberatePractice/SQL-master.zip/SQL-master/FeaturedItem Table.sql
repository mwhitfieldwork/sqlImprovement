use CityTour
go

create table Featured (
						Id int,	
						ProductId int)