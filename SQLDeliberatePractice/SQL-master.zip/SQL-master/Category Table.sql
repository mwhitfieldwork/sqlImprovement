USE CityTour

go

CREATE TABLE Category
  (
     Id  INT,
     Name VARCHAR(50)
  ) 
