use CityTour
go

insert into [Address]( Address1, Address2, City, [State], Zipcode, Country)
Values ( '217 South 51st', null, 'Bellwood', 'Illinois','60132', 'US'),
	   ( '2827 Gill St', null, 'Bloomington', 'Il','61708', 'US')