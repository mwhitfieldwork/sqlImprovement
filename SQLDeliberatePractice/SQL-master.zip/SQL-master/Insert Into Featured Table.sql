use CityTour
go

--select p.Id, p.Name, c.Name
--from Product p
--inner join Category c on c.id = p.CategoryId

insert into Featured (ProductId)
values
		(1),
		(2),
		(3),
		(6),
		(7),
		(8),
		(12),
		(13),
		(14)