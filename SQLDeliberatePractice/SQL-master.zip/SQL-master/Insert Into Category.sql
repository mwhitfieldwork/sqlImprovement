use CityTour
go

Insert into Category (Name)
values ( 'Church'),
		('Musuem'),
		('Building')